import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TableManagementSection extends StatefulWidget {
  const TableManagementSection({super.key});

  @override
  State<TableManagementSection> createState() => _TableManagementSectionState();
}

class _TableManagementSectionState extends State<TableManagementSection> {
  // Mutable table data
  final List<Map<String, dynamic>> _tables = [
    {'id': 'T1', 'seats': 4, 'status': 'Available'},
    {'id': 'T2', 'seats': 2, 'status': 'Occupied'},
    {'id': 'T3', 'seats': 4, 'status': 'Available'},
    {'id': 'T4', 'seats': 6, 'status': 'Reserved'},
    {'id': 'T5', 'seats': 2, 'status': 'Available'},
    {'id': 'T6', 'seats': 8, 'status': 'Occupied'},
  ];

  void _showAddTableDialog() {
    final TextEditingController idController = TextEditingController();
    final TextEditingController seatsController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Add New Table',
            style: GoogleFonts.inter(fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: idController,
                decoration: InputDecoration(
                  labelText: 'Table ID (e.g., T7)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: seatsController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Number of Seats',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (idController.text.isNotEmpty && seatsController.text.isNotEmpty) {
                  setState(() {
                    _tables.add({
                      'id': idController.text,
                      'seats': int.tryParse(seatsController.text) ?? 2,
                      'status': 'Available',
                    });
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Table ${idController.text} added successfully!')),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
              ),
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Table & Seat Management',
              style: GoogleFonts.inter(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            ElevatedButton.icon(
              onPressed: _showAddTableDialog,
              icon: const Icon(Icons.add),
              label: const Text('Add Table'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Expanded(
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 250,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.1,
            ),
            itemCount: _tables.length,
            itemBuilder: (context, index) {
              final table = _tables[index];
              return Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(color: Colors.grey.withValues(alpha: 0.1), spreadRadius: 2, blurRadius: 8, offset: const Offset(0, 4)),
                  ],
                  border: Border.all(
                    color: _getTableColor(table['status']).withValues(alpha: 0.5),
                    width: 2,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.table_restaurant,
                      size: 48,
                      color: _getTableColor(table['status']),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Table ${table['id']}',
                      style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${table['seats']} Seats',
                      style: GoogleFonts.inter(color: Colors.grey.shade600),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getTableColor(table['status']).withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        table['status'],
                        style: TextStyle(
                          color: _getTableColor(table['status']),
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Color _getTableColor(String status) {
    switch (status) {
      case 'Available':
        return Colors.green;
      case 'Occupied':
        return Colors.red;
      case 'Reserved':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }
}
