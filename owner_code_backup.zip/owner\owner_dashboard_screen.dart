import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'analytics_section.dart';
import 'overview_section.dart';
import 'reservation_list_section.dart';
import 'reviews_section.dart';
import 'table_management_section.dart';

class OwnerDashboardScreen extends StatefulWidget {
  const OwnerDashboardScreen({super.key});

  @override
  State<OwnerDashboardScreen> createState() => _OwnerDashboardScreenState();
}

class _OwnerDashboardScreenState extends State<OwnerDashboardScreen> {
  int _selectedIndex = 0;

  final List<Widget> _sections = [
    const OverviewSection(),
    const ReservationListSection(),
    const ReviewsSection(),
    const TableManagementSection(),
    const AnalyticsSection(),
  ];

  final List<NavigationRailDestination> _navDestinations = const [
    NavigationRailDestination(
      icon: Icon(Icons.dashboard_outlined),
      selectedIcon: Icon(Icons.dashboard),
      label: Text('Overview'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.calendar_month_outlined),
      selectedIcon: Icon(Icons.calendar_month),
      label: Text('Reservations'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.star_outline),
      selectedIcon: Icon(Icons.star),
      label: Text('Reviews'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.table_restaurant_outlined),
      selectedIcon: Icon(Icons.table_restaurant),
      label: Text('Tables'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.bar_chart_outlined),
      selectedIcon: Icon(Icons.bar_chart),
      label: Text('Analytics'),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth >= 800) {
          // Desktop / Tablet layout
          return Scaffold(
            backgroundColor: const Color(0xFFF5F7FA),
            body: Row(
              children: [
                NavigationRail(
                  selectedIndex: _selectedIndex,
                  onDestinationSelected: (int index) {
                    setState(() {
                      _selectedIndex = index;
                    });
                  },
                  labelType: NavigationRailLabelType.all,
                  backgroundColor: Colors.white,
                  selectedIconTheme: IconThemeData(color: Theme.of(context).colorScheme.primary),
                  selectedLabelTextStyle: GoogleFonts.inter(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.bold,
                  ),
                  unselectedLabelTextStyle: GoogleFonts.inter(
                    color: Colors.grey.shade600,
                  ),
                  destinations: _navDestinations,
                  leading: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24.0),
                    child: Column(
                      children: [
                        Icon(Icons.workspace_premium, size: 40, color: Theme.of(context).colorScheme.primary),
                        const SizedBox(height: 8),
                        Text(
                          'Owner',
                          style: GoogleFonts.inter(
                            fontWeight: FontWeight.bold,
                            color: Colors.grey.shade800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const VerticalDivider(thickness: 1, width: 1, color: Color(0xFFE0E0E0)),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(24.0),
                    child: _sections[_selectedIndex],
                  ),
                ),
              ],
            ),
          );
        } else {
          // Mobile Layout
          return Scaffold(
            backgroundColor: const Color(0xFFF5F7FA),
            appBar: AppBar(
              title: Text(
                'Owner Dashboard',
                style: GoogleFonts.inter(fontWeight: FontWeight.w600, color: Colors.grey.shade800),
              ),
              backgroundColor: Colors.white,
              elevation: 0,
              iconTheme: IconThemeData(color: Colors.grey.shade800),
              actions: [
                IconButton(
                  icon: const Icon(Icons.notifications_none),
                  onPressed: () {
                    // Notifications Panel could show here
                  },
                ),
              ],
            ),
            drawer: Drawer(
              backgroundColor: Colors.white,
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  DrawerHeader(
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Icon(Icons.workspace_premium, size: 48, color: Colors.white),
                        const SizedBox(height: 8),
                        Text(
                          'StudySpace Owner',
                          style: GoogleFonts.inter(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                  ...List.generate(_navDestinations.length, (index) {
                    final dest = _navDestinations[index];
                    return ListTile(
                      leading: _selectedIndex == index ? dest.selectedIcon : dest.icon,
                      title: dest.label,
                      selected: _selectedIndex == index,
                      selectedColor: Theme.of(context).colorScheme.primary,
                      onTap: () {
                        setState(() {
                          _selectedIndex = index;
                        });
                        Navigator.pop(context);
                      },
                    );
                  }),
                ],
              ),
            ),
            body: Padding(
              padding: const EdgeInsets.all(16.0),
              child: _sections[_selectedIndex],
            ),
          );
        }
      },
    );
  }
}
