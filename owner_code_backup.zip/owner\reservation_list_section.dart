import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ReservationListSection extends StatefulWidget {
  const ReservationListSection({super.key});

  @override
  State<ReservationListSection> createState() => _ReservationListSectionState();
}

class _ReservationListSectionState extends State<ReservationListSection> {
  final List<Map<String, dynamic>> _allReservations = [
    {'name': 'John Doe', 'contact': 'john@example.com', 'date': '2023-11-01', 'time': '18:00', 'seats': 2, 'status': 'Confirmed'},
    {'name': 'Jane Smith', 'contact': 'jane@example.com', 'date': '2023-11-01', 'time': '19:30', 'seats': 4, 'status': 'Pending'},
    {'name': 'Michael Lee', 'contact': 'michael@example.com', 'date': '2023-11-02', 'time': '12:00', 'seats': 3, 'status': 'Confirmed'},
    {'name': 'Sarah Connor', 'contact': 'sarah@example.com', 'date': '2023-11-02', 'time': '20:00', 'seats': 6, 'status': 'Cancelled'},
    {'name': 'David Kim', 'contact': 'david@example.com', 'date': '2023-11-03', 'time': '18:30', 'seats': 2, 'status': 'Confirmed'},
  ];

  List<Map<String, dynamic>> _filteredReservations = [];

  @override
  void initState() {
    super.initState();
    _filteredReservations = List.from(_allReservations);
  }

  void _filterReservations(String query) {
    setState(() {
      _filteredReservations = _allReservations
          .where((res) => res['name'].toLowerCase().contains(query.toLowerCase()) || res['contact'].toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Reservations',
              style: GoogleFonts.inter(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.download, size: 18),
              label: const Text('Export CSV'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Search by name or email...',
              border: InputBorder.none,
              icon: Icon(Icons.search, color: Colors.grey),
            ),
            onChanged: _filterReservations,
          ),
        ),
        const SizedBox(height: 24),
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(color: Colors.grey.withValues(alpha: 0.1), spreadRadius: 2, blurRadius: 8, offset: const Offset(0, 4)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  child: DataTable(
                    headingRowColor: WidgetStateProperty.resolveWith((states) => Colors.grey.shade50),
                    columns: const [
                      DataColumn(label: Text('Customer', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Contact', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Date & Time', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Seats', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Status', style: TextStyle(fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Actions', style: TextStyle(fontWeight: FontWeight.bold))),
                    ],
                    rows: _filteredReservations.map((res) {
                      return DataRow(
                        cells: [
                          DataCell(Text(res['name'], style: GoogleFonts.inter(fontWeight: FontWeight.w500))),
                          DataCell(Text(res['contact'])),
                          DataCell(Text('${res['date']} at ${res['time']}')),
                          DataCell(Text(res['seats'].toString())),
                          DataCell(
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: _getStatusColor(res['status']).withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                res['status'],
                                style: TextStyle(color: _getStatusColor(res['status']), fontWeight: FontWeight.bold, fontSize: 12),
                              ),
                            ),
                          ),
                          DataCell(
                            Row(
                              children: [
                                IconButton(icon: const Icon(Icons.edit, size: 18, color: Colors.blue), onPressed: () {}),
                                IconButton(icon: const Icon(Icons.cancel, size: 18, color: Colors.red), onPressed: () {}),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Confirmed': return Colors.green;
      case 'Pending': return Colors.orange;
      case 'Cancelled': return Colors.red;
      default: return Colors.grey;
    }
  }
}
